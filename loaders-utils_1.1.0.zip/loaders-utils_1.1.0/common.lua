if script then
   mods = script.active_mods
end

require "common.loaders-snap"
require "common.loaders-work"
require "common.setting-reloader"
